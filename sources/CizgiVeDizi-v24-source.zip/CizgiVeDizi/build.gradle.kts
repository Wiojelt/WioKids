version = 24


android {
    sourceSets.getByName("main").kotlin.directories += rootProject.file("common/src/main/kotlin").path
}

cloudstream {
    language = "tr"
    description = "Çocuklar için 13 kategoride çizgi diziler ve animasyon filmleri; güncel bölümler ve kaynaklar."
    status = 1
    tvTypes = listOf("Movie", "TvSeries")
    iconUrl = "https://raw.githubusercontent.com/Wiojelt/WioKids/main/assets/providers/CizgiVeDizi.png"
}
