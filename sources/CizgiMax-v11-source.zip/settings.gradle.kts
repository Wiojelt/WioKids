pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
    }
}

plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}

rootProject.name = "TurkSinema"

val buildTool = file(".build-tools/cloudstream-gradle")
check(buildTool.resolve("settings.gradle.kts").isFile) {
    "Run git submodule update --init --recursive before building."
}
includeBuild(buildTool) {
    name = "cloudstream-build-tool"
    dependencySubstitution {
        substitute(module("com.github.recloudstream.gradle:gradle")).using(project(":"))
    }
}

include("TurkSinema")
include("WioSinema")
include("WioCinema")
include("TurkishCineStream")
include("WioAnime")
include("WioAsya")
include("AsyaWatch")
include("InatBox")
include("RecTV")
include("YesilCamTv")
include("PowerSinema")
include("CineCat")
include("DiziAsya")
include("BingeBang")
include("Mapple")
include("Dmax")
include("CizgiVeDizi")
include("MegaWio")
include("MinikaCocuk")
include("MinikaGO")
include("CizgiPortal")
include("CizgiFilmIzleInfo")
include("IzleOyna")
include("CizgiFilmTv")
include("CizgiDiziNet")
include("CizgiSite")

// BEGIN GENERATED PROVIDERS
include("CineSimkl")
include("CNCVerseNetflix")
include("CNCVersePrimeVideo")
include("CNCVerseDisneyPlus")
include("DiziPalOriginal")
include("HDFilmDelisi")
include("SezonlukDizi")
include("Watch2Movies")
include("WebteIzle")
include("ClipBox")
include("FlixNetwork")
include("HDFilmIzleInk")
include("HDFilmIzleVip")
include("TrDiziIzle")
include("DiziBal")
include("DiziRella")
include("DiziBol")
include("FilmIzzle")
include("LiderFilmIzle")
include("DiziFilmIzle")
include("YabanciDizi")
include("AltiYuzAltmisAltiFilmIzle")
include("AnimeciX")
include("AsyaAnimeleri")
include("BelgeselX")
include("CizgiMax")
include("DDizi")
include("DiziBox")
include("DiziKorea")
include("Dizilla")
include("DiziMom")
include("SelcukFlix")
include("DiziPal")
include("DiziYou")
include("FilmMakinesi")
include("FilmModu")
include("FullHDFilm")
include("FullHDFilmizlesene")
include("HDFilmCehennemi")
include("JetFilmizle")
include("KultFilmler")
include("RareFilmm")
include("SetFilmIzle")
include("SinemaCX")
include("Sinewix")
include("Tlctr")
include("TRanimaci")
include("TRasyalog")
include("TurkAnime")
include("HDFilmizleBest")
include("NetFilmizle")
include("Sinemakolik")
include("SinemaGG")
include("Deokwave")
include("Anizium")
include("DramaDizilerim")
include("NetShort")
include("WebDramaTurkey")
include("AniArsiv")
include("TrAnimeIzle")
// END GENERATED PROVIDERS
