package dev.wiojelt.turksinema.entry

import android.content.Context
import com.lagradost.cloudstream3.APIHolder
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin
import dev.wiojelt.turksinema.common.DomainUpdateUi
import dev.wiojelt.turksinema.common.SupportNotice

@CloudstreamPlugin
class CizgiMaxEntry : Plugin() {
    private val delegate = dev.wiojelt.turksinema.vendor.saloo_cizgimax.com.keyiflerolsun.CizgiMaxPlugin()

    override fun load(context: Context) {
        val selected = synchronized(APIHolder.allProviders) {
            val before = APIHolder.allProviders.toSet()
            delegate.filename = filename
            delegate.load(context)
            val added = APIHolder.allProviders.filterNot(before::contains).toList()
            val keep = added.getOrNull(0)
            added.filterNot { it === keep }.forEach { provider ->
                APIHolder.removePluginMapping(provider)
                APIHolder.allProviders.remove(provider)
            }
            keep
        }
        DomainUpdateUi.attach(this, context, listOfNotNull(selected))
        SupportNotice.showIfDue(context)
    }

    override fun beforeUnload() = delegate.beforeUnload()
}
