import com.android.build.api.dsl.LibraryExtension
import com.lagradost.cloudstream3.gradle.CloudstreamExtension
import org.gradle.api.plugins.JavaPluginExtension
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.tasks.KotlinJvmCompile
import java.util.Properties

buildscript {
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
    }

    dependencies {
        classpath("com.android.tools.build:gradle:9.1.1")
        classpath("com.github.recloudstream.gradle:gradle:32895aedb6366f5075cb99bbd2e6ce0a7cac325d")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.0")
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
    }
}

fun Project.cloudstream(configuration: CloudstreamExtension.() -> Unit) =
    extensions.getByName<CloudstreamExtension>("cloudstream").configuration()

fun Project.android(configuration: LibraryExtension.() -> Unit) {
    extensions.getByName<LibraryExtension>("android").apply {
        project.extensions.findByType(JavaPluginExtension::class.java)?.toolchain {
            languageVersion.set(JavaLanguageVersion.of(17))
        }
        configuration()
    }
}

subprojects {
    apply(plugin = "com.android.library")
    apply(plugin = "com.lagradost.cloudstream3.gradle")

    cloudstream {
        setRepo(
            System.getenv("TURKSINEMA_REPOSITORY")
                ?: System.getenv("GITHUB_REPOSITORY")
                ?: "Wiojelt/TurkSinema"
        )
        authors = listOf("Wiojelt")
    }

    android {
        namespace = "dev.wiojelt.turksinema"
        compileSdk = 36

        val properties = Properties()
        val localPropertiesFile = rootProject.file("local.properties")
        if (localPropertiesFile.exists()) localPropertiesFile.inputStream().use(properties::load)
        fun getProp(key: String): String = System.getenv(key) ?: properties.getProperty(key) ?: ""
        buildFeatures.buildConfig = true

        defaultConfig {
            minSdk = 23
            val defaultTmdb = "500330721680edb6d5f7f12ba7cd9023"
            buildConfigField("String", "SIMKL_API", "\"${getProp("SIMKL_API")}\"")
            buildConfigField("String", "TMDB_KEY", "\"${getProp("TMDB_KEY").ifEmpty { defaultTmdb }}\"")
            buildConfigField("String", "CC_COOKIE", "\"${getProp("CC_COOKIE")}\"")
            buildConfigField("String", "CASTLE_KEY", "\"${getProp("CASTLE_KEY")}\"")
            buildConfigField("String", "MOVIEBLAST_TOKEN", "\"${getProp("MOVIEBLAST_TOKEN")}\"")
            buildConfigField("String", "MOVIEBLAST_API", "\"${getProp("MOVIEBLAST_API")}\"")
            buildConfigField("String", "MOVIEBLAST_KEY", "\"${getProp("MOVIEBLAST_KEY")}\"")
            buildConfigField("String", "NETMIRROR_TOKEN", "\"${getProp("NETMIRROR_TOKEN")}\"")
        }

        lint {
            targetSdk = 36
        }

        compileOptions {
            sourceCompatibility = JavaVersion.VERSION_11
            targetCompatibility = JavaVersion.VERSION_11
        }
    }

    tasks.withType<KotlinJvmCompile>().configureEach {
        compilerOptions {
            jvmTarget.set(JvmTarget.JVM_11)
            freeCompilerArgs.addAll(
                "-Xno-call-assertions",
                "-Xno-param-assertions",
                "-Xno-receiver-assertions",
                "-opt-in=com.lagradost.cloudstream3.Prerelease",
            )
        }
    }

    dependencies {
        val implementation by configurations
        val cloudstream by configurations

        cloudstream("com.lagradost:cloudstream3:pre-release")
        implementation(kotlin("stdlib"))
        implementation("com.github.Blatzar:NiceHttp:0.4.18")
        implementation("org.jsoup:jsoup:1.22.2")
        implementation("org.jspecify:jspecify:1.0.0")
        implementation("androidx.annotation:annotation:1.10.0")
        implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.13.1")
        implementation("com.fasterxml.jackson.core:jackson-databind:2.13.1")
        implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
        implementation("org.mozilla:rhino:1.8.1")
        implementation("me.xdrop:fuzzywuzzy:1.4.0")
        implementation("com.google.code.gson:gson:2.14.0")
        implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.11.0")
        implementation("org.bouncycastle:bcpkix-jdk18on:1.84")
        add("compileOnly", "com.google.android.material:material:1.12.0")
    }
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
