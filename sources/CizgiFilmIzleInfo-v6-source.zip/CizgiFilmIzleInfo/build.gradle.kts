version = 6

android {
    sourceSets.getByName("main").kotlin.directories += rootProject.file("common/src/main/kotlin").path
}

cloudstream {
    language = "tr"
    description = "WioKids · Cizgifilmizle.info çizgi film arşivi"
    status = 1
    tvTypes = listOf("Cartoon", "TvSeries", "Movie")
    iconUrl = "https://www.google.com/s2/favicons?domain=cizgifilmizle.info&sz=128"
}
