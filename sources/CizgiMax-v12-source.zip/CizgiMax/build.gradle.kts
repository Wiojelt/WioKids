version = 12

android {
    sourceSets.getByName("main").kotlin.directories += listOf(
        rootProject.file("TurkSinema/src/main/kotlin/dev/wiojelt/turksinema/vendor/saloo_cizgimax").path,
        rootProject.file("common/src/main/kotlin").path
    )
}

cloudstream {
    language = "tr"
    description = "Cizgi Max · TurkSinema ayrı sağlayıcı paketi"
    status = 1
    tvTypes = listOf("Movie", "TvSeries", "Anime", "Documentary")
    iconUrl = "https://www.google.com/s2/favicons?domain=cizgimax.online&sz=128"
}
